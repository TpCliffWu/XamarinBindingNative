//
//  MagicTool.h
//  MagicTool
//
//  Created by thinkpower on 2021/4/13.
//

#import <Foundation/Foundation.h>

//! Project version number for MagicTool.
FOUNDATION_EXPORT double MagicToolVersionNumber;

//! Project version string for MagicTool.
FOUNDATION_EXPORT const unsigned char MagicToolVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MagicTool/PublicHeader.h>


