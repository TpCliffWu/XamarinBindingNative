//
//  NativeiOSApp.swift
//  NativeiOS
//
//  Created by thinkpower on 2021/4/14.
//

import SwiftUI

@main
struct NativeiOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
